create view cast_movies as 
select id,movieName,cast from moviedetails;

select * from cast_movies;